package kissteria;



public class Main {
    public static void main(String[] args) {
        new TelaPlay().setVisible(true);
    }
}
